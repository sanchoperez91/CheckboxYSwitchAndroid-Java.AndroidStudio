package com.example.checkboxyswitch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private CheckBox deporte, musica, cine;

    private Switch datos;

    private Button comprobar;
    boolean comprobardatos=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cine = findViewById(R.id.cine);
        deporte = findViewById(R.id.deporte);
        musica = findViewById(R.id.musica);
        datos = findViewById(R.id.datos);
        comprobar = findViewById(R.id.comprobar);
    }

    public void mostrar(View view) {
       if( comprobardatos) {
           if (cine.isChecked()) {
               Toast.makeText(this, "Se ha marcado cine", Toast.LENGTH_SHORT).show();
           }

           if (deporte.isChecked()) {
               Toast.makeText(this, "Se ha marcado deporte", Toast.LENGTH_SHORT).show();
           }
           if (musica.isChecked()) {
               Toast.makeText(this, "Se ha marcado musica", Toast.LENGTH_SHORT).show();
           }
       }else{
           Toast.makeText(this, "Marque el switch para mostrar datos y pulse boton de nuevo", Toast.LENGTH_SHORT).show();
       }

    }
    public void verificar(View view){
        if (datos.isChecked()){
            Toast.makeText(this, "Datos Activados", Toast.LENGTH_SHORT).show();
            comprobardatos=true;

        }else{
            comprobardatos=false;
        }
    }
}